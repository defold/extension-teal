lua_version = "5.1"
variables = {
   CC = "x86_64-w64-mingw32-gcc",
   LD = "x86_64-w64-mingw32-gcc"
}
